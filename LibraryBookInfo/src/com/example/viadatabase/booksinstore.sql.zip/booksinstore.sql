-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 05, 2014 at 10:43 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `librarydata`
--

-- --------------------------------------------------------

--
-- Table structure for table `booksinstore`
--

CREATE TABLE IF NOT EXISTS `booksinstore` (
  `BookName` varchar(65) NOT NULL,
  `Author` varchar(35) NOT NULL,
  `BookId` varchar(25) NOT NULL,
  `Location` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booksinstore`
--

INSERT INTO `booksinstore` (`BookName`, `Author`, `BookId`, `Location`) VALUES
('Mobile', 'DicksonGT', 'bk13', 'shelf 4 row23'),
('Symmetric of Things', 'John Horton', 'bk24', 'shelf 7 row2'),
('Internet Security', 'Funja', 'bk18', 'shelf 5 row 3'),
('Oracle11g', 'Magolinya', 'bk11', 'shelf 2 row4'),
('Database', 'Abdul', 'bk17', 'shelf7 row 3'),
('Mathematics juniour', 'Mwaky', 'bk22', 'Shelf 6 row 3'),
('Hobbit', 'null', 'bk18', 'null'),
('White Fang', 'White London', 'bk21', 'shelf 7 row1'),
('Great Expectation', 'Charles Dinken', 'bk20', 'shelf7 row1'),
('Java Beans', 'Fat Brain', 'bk24', 'shelf 7 row3'),
('Book of Numbers', 'Fat Brown', 'bk26', 'shelf 7 row 3');
