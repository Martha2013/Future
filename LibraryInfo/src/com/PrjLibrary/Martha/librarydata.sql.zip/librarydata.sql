-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 08, 2014 at 04:55 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `librarydata`
--

-- --------------------------------------------------------

--
-- Table structure for table `booksinstore`
--

CREATE TABLE IF NOT EXISTS `booksinstore` (
  `BookName` varchar(65) NOT NULL,
  `Author` varchar(35) NOT NULL,
  `BookId` varchar(25) NOT NULL,
  `Location` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booksinstore`
--

INSERT INTO `booksinstore` (`BookName`, `Author`, `BookId`, `Location`) VALUES
('Mobile', 'DicksonGT', 'Book45', 'shelf 7 row 3'),
('Symmetric of Things', 'John Horton', 'bk24', 'shelf 7 row2'),
('Internet Security', 'Funja', 'bk18', 'shelf 5 row 3'),
('Oracle11g', 'Magolinya', 'bk11', 'shelf 2 row4'),
('Database', 'Abdul', 'bk17', 'shelf7 row 3'),
('Mathematics juniour', 'Mwaky', 'bk22', 'Shelf 6 row 3'),
('Hobbit', 'null', 'bk18', 'null'),
('White Fang', 'White London', 'bk21', 'shelf 7 row1'),
('Great Expectation', 'Charles Dinken', 'bk20', 'shelf7 row1'),
('Java Beans', 'Fat Brain', 'bk24', 'shelf 7 row3'),
('Book of Numbers', 'Fat Brown', 'bk26', 'shelf 7 row 3'),
('Ict Law', 'Mziray', 'bk23', 'shelf 5 row 3');

-- --------------------------------------------------------

--
-- Table structure for table `booksreturned`
--

CREATE TABLE IF NOT EXISTS `booksreturned` (
  `Id` int(4) NOT NULL AUTO_INCREMENT,
  `BookName` varchar(30) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `booksreturned`
--

INSERT INTO `booksreturned` (`Id`, `BookName`, `Date`) VALUES
(1, 'Ict Law', '2014-02-08');

-- --------------------------------------------------------

--
-- Table structure for table `bookstaken`
--

CREATE TABLE IF NOT EXISTS `bookstaken` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `BookNames` varchar(65) NOT NULL,
  `UserName` varchar(36) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `bookstaken`
--

INSERT INTO `bookstaken` (`Id`, `BookNames`, `UserName`, `Date`) VALUES
(1, 'Java Programming', 'Martha', '2014-01-21');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `Name` varchar(23) NOT NULL,
  `LibraryId` varchar(8) NOT NULL,
  `Work` varchar(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`Name`, `LibraryId`, `Work`) VALUES
('Martha', 'Student', 'lib11'),
('Assa', 'lib12', 'Teacher'),
('myu', '56', 'yh'),
('Marthayu', 'lib23', 'Student'),
('Ndimumi', 'lib90', 'Housewife'),
('Assa', 'lib45', 'Student'),
('Zuhery', 'lib12345', 'Economist');
